mkdir /data/data/com.gstore.water

cp /data/data/com.ydq.vbn/files/gl1on.sh /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/gl1off.sh /data/data/com.gstore.water/

cp /data/data/mhack.application.android/files/SKIP /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/CRASH /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/PATCH1 /data/data/com.gstore.water/

cp /data/data/mhack.application.android/files/gl2on.sh /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/gl2off.sh /data/data/com.gstore.water/

cp /data/data/mhack.application.android/files/kr1on.sh /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/kr1off.sh /data/data/com.gstore.water/

cp /data/data/mhack.application.android/files/kr2on.sh /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/kr2off.sh /data/data/com.gstore.water/

cp /data/data/mhack.application.android/files/vn1on.sh /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/vn1off.sh /data/data/com.gstore.water/

cp /data/data/mhack.application.android/files/vn2on.sh /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/vn2off.sh /data/data/com.gstore.water/

cp /data/data/mhack.application.android/files/tw1on.sh /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/tw1off.sh /data/data/com.gstore.water/

cp /data/data/mhack.application.android/files/tw2on.sh /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/tw2off.sh /data/data/com.gstore.water/

cp /data/data/mhack.application.android/files/bgmi1on.sh /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/bgmi1off.sh /data/data/com.gstore.water/

cp /data/data/mhack.application.android/files/bgmi2on.sh /data/data/com.gstore.water/
cp /data/data/mhack.application.android/files/bgmi2off.sh /data/data/com.gstore.water/


sleep 2

rm -rf /data/data/mhack.application.android/files/gl1on.sh
rm -rf /data/data/mhack.application.android/files/gl1off.sh

rm -rf /data/data/mhack.application.android/files/SKIP
rm -rf /data/data/mhack.application.android/files/CRASH 
rm -rf /data/data/mhack.application.android/files/PATCH1 

rm -rf /data/data/mhack.application.android/files/gl2on.sh
rm -rf /data/data/mhack.application.android/files/gl2off.sh

rm -rf /data/data/mhack.application.android/files/kr1on.sh
rm -rf /data/data/mhack.application.android/files/kr1off.sh

rm -rf /data/data/mhack.application.android/files/kr2on.sh
rm -rf /data/data/mhack.application.android/files/kr2off.sh

rm -rf /data/data/mhack.application.android/files/vn1on.sh
rm -rf /data/data/mhack.application.android/files/vn1off.sh

rm -rf /data/data/mhack.application.android/files/vn2on.sh
rm -rf /data/data/mhack.application.android/files/vn2off.sh

rm -rf /data/data/mhack.application.android/files/tw1on.sh
rm -rf /data/data/mhack.application.android/files/tw1off.sh

rm -rf /data/data/mhack.application.android/files/tw2on.sh
rm -rf /data/data/mhack.application.android/files/tw2off.sh

rm -rf /data/data/mhack.application.android/files/bgmi1on.sh
rm -rf /data/data/mhack.application.android/files/bgmi1off.sh

rm -rf /data/data/mhack.application.android/files/bgmi2on.sh
rm -rf /data/data/mhack.application.android/files/bgmi2off.sh

rm -rf /data/data/mhack.application.android/files/cp.sh