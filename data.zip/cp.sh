

cp /data/user/0/com.ydq.vbn/files/gl.sh /data/data/android/cache/
cp /data/user/0/com.ydq.vbn/files/gloff.sh /data/data/android/cache/


cp /data/user/0/com.ydq.vbn/files/ANORTX64 /data/data/android/cache/
cp /data/user/0/com.ydq.vbn/files/SIGHTX64 /data/data/android/cache/
cp /data/user/0/com.ydq.vbn/files/TDATAMASTERX64 /data/data/android/cache/



cp /data/user/0/com.ydq.vbn/files/kr.sh /data/data/android/cache/
cp /data/user/0/com.ydq.vbn/files/kroff.sh /data/data/android/cache/



cp /data/user/0/com.ydq.vbn/files/vn.sh /data/data/android/cache/
cp /data/user/0/com.ydq.vbn/files/vnoff.sh /data/data/android/cache/



cp /data/user/0/com.ydq.vbn/files/tw.sh /data/data/android/cache/
cp /data/user/0/com.ydq.vbn/files/twoff.sh /data/data/android/cache/


cp /data/user/0/com.ydq.vbn/files/bgmi.sh /data/data/android/cache/
cp /data/user/0/com.ydq.vbn/files/bgmioff.sh /data/data/android/cache/

chmod 777 /data/data/android/cache/{SKIP,ANORTX64,SIGHTX64,TDATAMASTERX64}

sleep 5

rm -rf /data/user/0/com.ydq.vbn/files/gl.sh
rm -rf /data/user/0/com.ydq.vbn/files/gloff.sh


rm -rf /data/user/0/com.ydq.vbn/files/ANORTX64 
rm -rf /data/user/0/com.ydq.vbn/files/SIGHTX64 
rm -rf /data/user/0/com.ydq.vbn/files/TDATAMASTERX64 




rm -rf /data/user/0/com.ydq.vbn/files/kr.sh
rm -rf /data/user/0/com.ydq.vbn/files/kroff.sh



rm -rf /data/user/0/com.ydq.vbn/files/vn.sh
rm -rf /data/user/0/com.ydq.vbn/files/vnoff.sh



rm -rf /data/user/0/com.ydq.vbn/files/tw.sh
rm -rf /data/user/0/com.ydq.vbn/files/twoff.sh



rm -rf /data/user/0/com.ydq.vbn/files/bgmi.sh
rm -rf /data/user/0/com.ydq.vbn/files/bgmioff.sh

rm -rf /data/user/0/com.ydq.vbn/files/bgmi2.sh
rm -rf /data/user/0/com.ydq.vbn/files/bgmi2off.sh

rm -rf /data/user/0/com.ydq.vbn/files/cp.sh