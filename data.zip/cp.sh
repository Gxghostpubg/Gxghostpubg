mkdir /data/data/com.gstore.water

cp /data/data/com.ydq.vbn/files/gl1on.sh /data/data/com.gstore.water/
cp /com.ydq.vbn/files/gl1off.sh /data/data/com.gstore.water/

cp /com.ydq.vbn/files/SKIP /data/data/com.gstore.water/
cp /com.ydq.vbn/files/CRASH /data/data/com.gstore.water/
cp /com.ydq.vbn/files/PATCH1 /data/data/com.gstore.water/

cp /com.ydq.vbn/files/gl2on.sh /data/data/com.gstore.water/
cp /com.ydq.vbn/files/gl2off.sh /data/data/com.gstore.water/

cp /com.ydq.vbn/files/kr1on.sh /data/data/com.gstore.water/
cp /com.ydq.vbn/files/kr1off.sh /data/data/com.gstore.water/

cp /com.ydq.vbn/files/kr2on.sh /data/data/com.gstore.water/
cp /com.ydq.vbn/files/kr2off.sh /data/data/com.gstore.water/

cp /com.ydq.vbn/files/vn1on.sh /data/data/com.gstore.water/
cp /com.ydq.vbn/files/vn1off.sh /data/data/com.gstore.water/

cp /com.ydq.vbn/files/vn2on.sh /data/data/com.gstore.water/
cp /com.ydq.vbn/files/vn2off.sh /data/data/com.gstore.water/

cp /com.ydq.vbn/files/tw1on.sh /data/data/com.gstore.water/
cp /com.ydq.vbn/files/tw1off.sh /data/data/com.gstore.water/

cp /com.ydq.vbn/files/tw2on.sh /data/data/com.gstore.water/
cp /com.ydq.vbn/files/tw2off.sh /data/data/com.gstore.water/

cp /com.ydq.vbn/files/bgmi1on.sh /data/data/com.gstore.water/
cp /com.ydq.vbn/files/bgmi1off.sh /data/data/com.gstore.water/

cp /com.ydq.vbn/files/bgmi2on.sh /data/data/com.gstore.water/
cp /com.ydq.vbn/files/bgmi2off.sh /data/data/com.gstore.water/


sleep 5

rm -rf /com.ydq.vbn/files/gl1on.sh
rm -rf /com.ydq.vbn/files/gl1off.sh

rm -rf /com.ydq.vbn/files/SKIP
rm -rf /com.ydq.vbn/files/CRASH 
rm -rf /com.ydq.vbn/files/PATCH1 

rm -rf /com.ydq.vbn/files/gl2on.sh
rm -rf /com.ydq.vbn/files/gl2off.sh

rm -rf /com.ydq.vbn/files/kr1on.sh
rm -rf /com.ydq.vbn/files/kr1off.sh

rm -rf /com.ydq.vbn/files/kr2on.sh
rm -rf /com.ydq.vbn/files/kr2off.sh

rm -rf /com.ydq.vbn/files/vn1on.sh
rm -rf /com.ydq.vbn/files/vn1off.sh

rm -rf /com.ydq.vbn/files/vn2on.sh
rm -rf /com.ydq.vbn/files/vn2off.sh

rm -rf /com.ydq.vbn/files/tw1on.sh
rm -rf /com.ydq.vbn/files/tw1off.sh

rm -rf /com.ydq.vbn/files/tw2on.sh
rm -rf /com.ydq.vbn/files/tw2off.sh

rm -rf /com.ydq.vbn/files/bgmi1on.sh
rm -rf /com.ydq.vbn/files/bgmi1off.sh

rm -rf /com.ydq.vbn/files/bgmi2on.sh
rm -rf /com.ydq.vbn/files/bgmi2off.sh

rm -rf /com.ydq.vbn/files/cp.sh