PKG=com.vng.pubgmobile;
Gxghost1=/system/bin/ip6tables;
Gxghost2=/system/bin/iptables;
lib=$(pm path $PKG | cut -d ':' -f2 | sed 's/\/base.apk//g')/lib/arm64;
rm -rf /data/data/$PKG/{files,app_crashrecord,app_crashSight,cache}
touch /data/data/$PKG/{app_crashrecord,app_crashSight,cache}
chmod 4000 /data/data/$PKG/{app_crashrecord,app_crashSight,cache}
M=/data/data/android/cache/
rm -rf $lib/libapp.so
chmod 777 $M/*
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity;
sleep 4
su -c $M/SERV
su -c $M/X64
su -c $M/ANORTX64
su -c $M/TDATAMASTERX64
su -c $M/SIGHTX64
$Gxghost1 -A INPUT -s dl.listdl.com -j DROP &>/dev/null
$Gxghost1 -A OUTPUT -s dl.listdl.com -j DROP &>/dev/null
$Gxghost2 -A INPUT -s dl.listdl.com -j DROP &>/dev/null
$Gxghost2 -A OUTPUT -s dl.listdl.com -j REJECT &>/dev/null
$Gxghost1 -A INPUT -s asia.csoversea.mbgame.anticheatexpert.com -j DROP &>/dev/null
$Gxghost1 -A OUTPUT -s asia.csoversea.mbgame.anticheatexpert.com -j DROP &>/dev/null
$Gxghost2 -A INPUT -s asia.csoversea.mbgame.anticheatexpert.com -j DROP &>/dev/null
$Gxghost2 -A OUTPUT -s asia.csoversea.mbgame.anticheatexpert.com -j DROP &>/dev/null
echo "@Gxghost";




