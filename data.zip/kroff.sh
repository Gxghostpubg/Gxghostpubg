am force-stop com.pubg.krmobile 
pm install -r $(pm path com.pubg.krmobile | awk -F ':' '{print $2}')
echo "@Gxghost";
