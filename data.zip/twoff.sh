IP6TABLES=/system/bin/ip6tables
IPTABLES=/system/bin/iptables
$IPTABLES -F
$IPTABLES -X
$IPTABLES -t nat -F
$IPTABLES -t nat -X
am force-stop com.rekoo.pubgm 
pm install -r $(pm path com.rekoo.pubgm | awk -F ':' '{print $2}')
echo "@Gxghost";
