am force-stop com.rekoo.pubgm 
pm install -r $(pm path com.rekoo.pubgm | awk -F ':' '{print $2}')
echo "@Gxghost";
