am force-stop com.pubg.imobile 
pm install -r $(pm path com.pubg.imobile | awk -F ':' '{print $2}')
echo "@Gxghost";
