am force-stop com.tencent.ig 
pm install -r $(pm path com.tencent.ig | awk -F ':' '{print $2}')
echo "@Gxghost";
