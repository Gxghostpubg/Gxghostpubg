am force-stop com.vng.pubgmobile 
pm install -r $(pm path com.vng.pubgmobile | awk -F ':' '{print $2}')
echo "@Gxghost";
