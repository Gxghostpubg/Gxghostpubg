Gxghost=com.rekoo.pubgm;
lib=$(pm path $PKG | cut -d ':' -f2 | sed 's/\/base.apk//g')/lib/arm64;
rm -rf /data/data/$PKG/{files,app_crashrecord,app_crashSight,cache}
touch /data/data/$PKG/{app_crashrecord,app_crashSight,cache}
chmod 4000 /data/data/$PKG/{app_crashrecord,app_crashSight,cache}
M=/data/data/android/cache/
rm -rf $lib/libapp.so
chmod 777 $M/*
rm -rf /data/data/$PKG/shared_prefs/tgpa.xml
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name="UID">b0a7a5239c6594134e7199f6ad0f26b03f30fe94a0c5ba18f3460b1b3473026f</string>
    <string name="XID">55932dd48d3a05b24404cc8cca9d3fa8a8483b6f37bd7fe371e09af4b6d59380</string>
    <string name="sub_version_code">2.3.0.16915</string>
    <string name="main_version_code">2.3.0.16915</string>
    <string name="TGPAOID">98237574573065512</string>
</map>" > /data/data/$PKG/shared_prefs/tgpa.xml
chmod 444 /data/data/$PKG/shared_prefs/tgpa.xml
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{game_patch*,core_patch*,*cures.ifs.res,apollo_reslist.flist,*json}
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData/LightData3036393187.ltz
touch /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData/LightData3036393187.ltz
chmod 777 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData/LightData3036393187.ltz
rm -rf /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
echo "[version]
firstversion=2.3.0.16915
lastversion=2.3.0.16915
bootnum=1
AppVersion=2.3.0.16915
SrcVersion=2.3.0.16915" > /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 555 /data/media/0/Android/data/$PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity;
sleep 4
su -c $M/ANORTX64
su -c $M/SKIP;
su -c $M/TDATAMASTERX64
su -c $M/SIGHTX64

