PKG=com.rekoo.pubgm;
lib=$(pm path $PKG | cut -d ':' -f2 | sed 's/\/base.apk//g')/lib/arm64;
rm -rf /data/data/$PKG/{files,app_crashrecord,app_crashSight,cache}
touch /data/data/$PKG/{app_crashrecord,app_crashSight,cache}
chmod 4000 /data/data/$PKG/{app_crashrecord,app_crashSight,cache}
M=/data/data/android/cache/
rm -rf $lib/libapp.so
cp $lib/libUE4.so $lib/libUE4.so.bak
cp $lib/libanogs.so $lib/libanogs.so.bak
chmod 777 $M/*
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity;
sleep 4
rm -rf $lib/{libanogs.so,libUE4.so}
mv $lib/libanogs.so.bak $lib/libanogs.so
mv $lib/libUE4.so.bak $lib/libUE4.so
su -c $M/ANORTX64
su -c $M/TDATAMASTERX64
su -c $M/SIGHTX64
echo "@Gxghost";



