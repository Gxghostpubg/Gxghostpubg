PKG=com.tencent.ig;
lib=$(pm path $PKG | cut -d ':' -f2 | sed 's/\/base.apk//g')/lib/arm64;
M=/data/data/android/cache/
rm -rf $lib/libapp.so
cp $M/PATCH $lib/libCrashSight.so 
chmod 755 $lib/libCrashSight.so
chmod 777 $M/*
su -c am start -n $PKG/com.epicgames.ue4.SplashActivity;
sleep 4
su -c $M/CRASH;
su -c $M/DATA;