/system/bin/iptables -F
/system/bin/iptables --flush
/system/bin/iptables -P INPUT ACCEPT
/system/bin/iptables -P FORWARD ACCEPT
/system/bin/iptables -P OUTPUT ACCEPT
/system/bin/iptables -t nat -F
/system/bin/iptables -t mangle -F
/system/bin/iptables -Xam force-stop com.pubg.krmobile 
pm install -r $(pm path com.pubg.krmobile | awk -F ':' '{print $2}')
echo "@Gxghost";
